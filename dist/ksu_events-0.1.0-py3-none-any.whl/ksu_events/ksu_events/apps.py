from django.apps import AppConfig


class KsuEventsConfig(AppConfig):
    name = 'ksu_events'
