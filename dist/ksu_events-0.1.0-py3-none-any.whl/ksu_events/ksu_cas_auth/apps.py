from django.apps import AppConfig


class BaseConfig(AppConfig):
    name = 'ksu_events.ksu_cas_auth'
