This is the package that is imported.

requires django 5 and python 3.10

setup for development within devcontainer

