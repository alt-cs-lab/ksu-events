# need to add all models here for them to be accessible
from ksu_events.registration.models.model_ethnicity_options import EthnicityOption
from ksu_events.registration.models.model_major_options import MajorOption
from ksu_events.registration.models.model_chaperone import Chaperone
from ksu_events.registration.models.model_participant_chaperone import ParticipantChaperone
from ksu_events.registration.models.model_participant import Participant
from ksu_events.registration.models.model_registration import Registrations