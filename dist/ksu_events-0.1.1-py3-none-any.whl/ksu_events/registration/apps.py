from django.apps import AppConfig


class RegistrationConfig(AppConfig):
    name = 'ksu_events.registration'
